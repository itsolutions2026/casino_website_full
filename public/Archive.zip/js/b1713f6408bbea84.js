"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["vendor/xumm-oauth2-pkce"],{

/***/ "./node_modules/xumm-oauth2-pkce/dist/index.js":
/*!*****************************************************!*\
  !*** ./node_modules/xumm-oauth2-pkce/dist/index.js ***!
  \*****************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.XummPkce = exports.XummPkceThread = void 0;
// import { debug as Debug } from "debug";
const events_1 = __webpack_require__(/*! events */ "./node_modules/events/events.js");
const xumm_sdk_1 = __webpack_require__(/*! xumm-sdk */ "./node_modules/xumm-sdk/dist/src/index.js");
const xumm_js_pkce_1 = __importDefault(__webpack_require__(/*! xumm-js-pkce */ "./node_modules/xumm-js-pkce/dist/PKCE.js"));
const log = function (...args) {
    if (typeof localStorage !== "undefined") {
        if (localStorage === null || localStorage === void 0 ? void 0 : localStorage.debug) {
            console.log(...args);
        }
    }
};
// localStorage.debug = "xummpkce*";
// Debug.log = log.bind(console);
// const log = Debug("xummpkce");
// If everything else fails:
// const log = (...args: any[]) => {
//   alert(args.map((a) => JSON.stringify(a, null, 2)).join(" "));
// };
if (typeof window !== "undefined") {
    log("Xumm OAuth2 PKCE Authorization Code Flow lib.");
}
const EventReadyPromise = (event) => {
    let _resolve = (value) => { };
    const promise = new Promise((resolve) => {
        _resolve = resolve;
    });
    return {
        promise,
        resolve: (value) => {
            // log("XummPKCE <Resolving eventReadyPromise>", event);
            return _resolve(value);
        },
    };
};
class XummPkceThread extends events_1.EventEmitter {
    constructor(xummApiKey, optionsOrRedirectUrl) {
        var _a, _b;
        super();
        this.popup = null;
        this.resolved = false;
        this.mobileRedirectFlow = false;
        this.eventPromises = {
            retrieved: EventReadyPromise("retrieved"),
            error: EventReadyPromise("error"),
            success: EventReadyPromise("success"),
            loggedout: EventReadyPromise("loggedout"),
        };
        this.options = {
            redirectUrl: document.location.href,
            rememberJwt: true,
            storage: localStorage,
            implicit: false,
        };
        /**
         * Apply options
         */
        if (typeof optionsOrRedirectUrl === "string") {
            this.options.redirectUrl = optionsOrRedirectUrl;
        }
        else if (typeof optionsOrRedirectUrl === "object" &&
            optionsOrRedirectUrl) {
            if (typeof optionsOrRedirectUrl.redirectUrl === "string") {
                this.options.redirectUrl = optionsOrRedirectUrl.redirectUrl;
            }
            if (typeof optionsOrRedirectUrl.rememberJwt === "boolean") {
                this.options.rememberJwt = optionsOrRedirectUrl.rememberJwt;
            }
            if (typeof optionsOrRedirectUrl.storage === "object") {
                this.options.storage = optionsOrRedirectUrl.storage;
            }
            if (typeof optionsOrRedirectUrl.implicit === "boolean") {
                this.options.implicit = optionsOrRedirectUrl.implicit;
            }
        }
        /**
         * Construct
         */
        const pkceOptions = {
            client_id: xummApiKey,
            redirect_uri: this.options.redirectUrl,
            authorization_endpoint: "https://oauth2.xumm.app/auth",
            token_endpoint: "https://oauth2.xumm.app/token",
            requested_scopes: "XummPkce",
            storage: this.options.storage,
            implicit: this.options.implicit,
        };
        // log(JSON.stringify(pkceOptions, null, 2));
        this.pkce = new xumm_js_pkce_1.default(pkceOptions);
        /**
         * Check if there is already a valid JWT to be used
         */
        if (this.options.rememberJwt) {
            log("Remember JWT");
            try {
                const existingJwt = JSON.parse(((_a = this.options.storage) === null || _a === void 0 ? void 0 : _a.getItem("XummPkceJwt")) || "{}");
                if ((existingJwt === null || existingJwt === void 0 ? void 0 : existingJwt.jwt) && typeof existingJwt.jwt === "string") {
                    const sdk = new xumm_sdk_1.XummSdkJwt(existingJwt.jwt);
                    this.ping = sdk.ping();
                    this.ping
                        .then((pong) => __awaiter(this, void 0, void 0, function* () {
                        var _c;
                        /**
                         * Pretend mobile so no window.open is triggered
                         */
                        if ((_c = pong === null || pong === void 0 ? void 0 : pong.jwtData) === null || _c === void 0 ? void 0 : _c.sub) {
                            // Yay, user still signed in, JWT still valid!
                            this.autoResolvedFlow = Object.assign(existingJwt, { sdk });
                            yield this.authorize();
                            this.emit("retrieved");
                        }
                        else {
                            this.logout();
                        }
                    }))
                        .catch((e) => {
                        // That didn't work
                        this.logout();
                    });
                }
                else {
                    this.logout();
                }
            }
            catch (e) {
                // Do nothing
            }
        }
        window.addEventListener("message", (event) => {
            var _a;
            log("Received Event from ", event.origin);
            if (String((event === null || event === void 0 ? void 0 : event.data) || "").slice(0, 1) === "{" &&
                String((event === null || event === void 0 ? void 0 : event.data) || "").slice(-1) === "}") {
                log("Got PostMessage with JSON");
                if (event.origin === "https://xumm.app" ||
                    event.origin === "https://oauth2.xumm.app") {
                    log("Got PostMessage from https://xumm.app / https://oauth2.xumm.app");
                    try {
                        const postMessage = JSON.parse(event.data);
                        if ((postMessage === null || postMessage === void 0 ? void 0 : postMessage.source) === "xumm_sign_request" &&
                            (postMessage === null || postMessage === void 0 ? void 0 : postMessage.payload)) {
                            log("Payload opened:", postMessage.payload);
                        }
                        else if ((postMessage === null || postMessage === void 0 ? void 0 : postMessage.source) === "xumm_sign_request_resolved" &&
                            (postMessage === null || postMessage === void 0 ? void 0 : postMessage.options)) {
                            // log("Payload resolved:", postMessage.options);
                            log("Payload resolved, mostmessage containing options containing redirect URL: ", postMessage);
                            /**
                             * Beat the 750ms timing for the window close as the exchange
                             * may still take a whil (async HTTP call). We don't know YET
                             * if we resolved successfully but we sure did resolve.
                             */
                            this.resolved = true;
                            this.pkce
                                .exchangeForAccessToken(postMessage.options.full_redirect_uri)
                                .then((resp) => {
                                this.jwt = resp.access_token;
                                if (resp === null || resp === void 0 ? void 0 : resp.error_description) {
                                    throw new Error(resp === null || resp === void 0 ? void 0 : resp.error_description);
                                }
                                // if (this.resolvePromise) {
                                //   this.resolvePromise({
                                //     jwt: this.jwt,
                                //     sdk: new XummSdkJwt(this.jwt),
                                //   });
                                // }
                                fetch("https://oauth2.xumm.app/userinfo", {
                                    headers: {
                                        Authorization: "Bearer " + resp.access_token,
                                    },
                                })
                                    .then((r) => r.json())
                                    .then((me) => {
                                    var _a;
                                    if (this.resolvePromise) {
                                        if (this.options.rememberJwt) {
                                            log("Remembering JWT");
                                            try {
                                                (_a = this.options.storage) === null || _a === void 0 ? void 0 : _a.setItem("XummPkceJwt", JSON.stringify({ jwt: resp.access_token, me }));
                                            }
                                            catch (e) {
                                                log("Could not persist JWT to local storage", e);
                                            }
                                        }
                                        this.resolvePromise({
                                            jwt: resp.access_token,
                                            sdk: new xumm_sdk_1.XummSdkJwt(resp.access_token),
                                            me,
                                        });
                                    }
                                });
                                // Do stuff with the access token.
                            })
                                .catch((e) => {
                                if (this.rejectPromise) {
                                    this.rejectPromise((e === null || e === void 0 ? void 0 : e.error) ? new Error(e.error) : e);
                                }
                                log((e === null || e === void 0 ? void 0 : e.error) || e);
                            });
                        }
                        else if ((postMessage === null || postMessage === void 0 ? void 0 : postMessage.source) === "xumm_sign_request_rejected") {
                            log("Payload rejected", postMessage === null || postMessage === void 0 ? void 0 : postMessage.options);
                            if (this.rejectPromise) {
                                this.rejectPromise(new Error(((_a = postMessage === null || postMessage === void 0 ? void 0 : postMessage.options) === null || _a === void 0 ? void 0 : _a.error_description) ||
                                    "Payload rejected"));
                            }
                        }
                        else if ((postMessage === null || postMessage === void 0 ? void 0 : postMessage.source) === "xumm_sign_request_popup_closed") {
                            log("Popup closed, wait 750ms");
                            // Wait, maybe the real reason comes in later (e.g. explicitly rejected)
                            setTimeout(() => {
                                if (!this.resolved && this.rejectPromise) {
                                    this.rejectPromise(new Error("Sign In window closed"));
                                }
                            }, 750);
                        }
                        else {
                            log("Unexpected message, skipping", postMessage === null || postMessage === void 0 ? void 0 : postMessage.source);
                        }
                    }
                    catch (e) {
                        log("Error parsing message", (e === null || e === void 0 ? void 0 : e.message) || e);
                    }
                }
            }
        }, false);
        const params = new URLSearchParams(((_b = document === null || document === void 0 ? void 0 : document.location) === null || _b === void 0 ? void 0 : _b.search) || "");
        if (params.get("authorization_code") ||
            params.get("access_token") ||
            params.get("error_description")) {
            this.mobileRedirectFlow = true;
            this.urlParams = params;
            let documentReadyExecuted = false;
            const onDocumentReady = (event) => __awaiter(this, void 0, void 0, function* () {
                log("onDocumentReady", document.readyState);
                if (!documentReadyExecuted && document.readyState === "complete") {
                    documentReadyExecuted = true;
                    log("(readystatechange: [ " + document.readyState + " ])");
                    this.handleMobileGrant();
                    yield this.authorize();
                    this.emit("retrieved");
                }
            });
            onDocumentReady();
            document.addEventListener("readystatechange", onDocumentReady);
        }
    }
    emit(event, ...args) {
        // log("emitting event", event, ...args);
        // log("subscribers for event", event, this.listenerCount(event));
        this.eventPromises[event].promise.then(() => {
            // Emit when subscribed
            return super.emit(event, ...args);
        });
        return true;
    }
    on(event, listener) {
        // log("event added, on", event);
        this.eventPromises[event].resolve();
        return super.on(event, listener);
    }
    off(event, listener) {
        // log("event removed, off", event);
        // Reset promise
        this.eventPromises[event] = EventReadyPromise(event);
        return super.off(event, listener);
    }
    // Todo: document, e.g. custom flow, plugin
    authorizeUrl() {
        return this.pkce.authorizeUrl();
    }
    handleMobileGrant() {
        if (this.urlParams && this.mobileRedirectFlow) {
            // log("Send message event");
            const messageEventData = {
                data: JSON.stringify(this.urlParams.get("authorization_code") ||
                    this.urlParams.get("access_token")
                    ? {
                        source: "xumm_sign_request_resolved",
                        options: {
                            full_redirect_uri: document.location.href,
                        },
                    }
                    : {
                        source: "xumm_sign_request_rejected",
                        options: {
                            error: this.urlParams.get("error"),
                            error_code: this.urlParams.get("error_code"),
                            error_description: this.urlParams.get("error_description"),
                        },
                    }),
                origin: "https://oauth2.xumm.app",
            };
            const event = new MessageEvent("message", messageEventData);
            window.dispatchEvent(event);
            return true;
        }
        return false;
    }
    authorize() {
        return __awaiter(this, void 0, void 0, function* () {
            // Do not authorize twice
            if (this.resolvedSuccessfully) {
                return this.promise;
            }
            this.resolved = false;
            try {
                yield this.ping;
            }
            catch (e) {
                // Nope (prevent 401 error from API to bleed into auth flow)
            }
            if (!this.mobileRedirectFlow && !this.autoResolvedFlow) {
                const url = this.authorizeUrl();
                const popup = window.open(url, "XummPkceLogin", "directories=no,titlebar=no,toolbar=no,location=no,status=no," +
                    "menubar=no,scrollbars=no,resizable=no,width=600,height=790");
                this.popup = popup;
                log("Popup opened...", url);
            }
            this.resolved = false;
            const clearUrlParams = () => {
                var _a;
                const newUrlParams = new URLSearchParams(((_a = document === null || document === void 0 ? void 0 : document.location) === null || _a === void 0 ? void 0 : _a.search) || "");
                // PKCE
                newUrlParams.delete("authorization_code");
                newUrlParams.delete("code");
                newUrlParams.delete("scope");
                newUrlParams.delete("state");
                // Implicit
                newUrlParams.delete("access_token");
                newUrlParams.delete("refresh_token");
                newUrlParams.delete("token_type");
                newUrlParams.delete("expires_in");
                const newSearchParamsString = newUrlParams.toString();
                const url = document.location.href.split("?")[0] +
                    (newSearchParamsString !== "" ? "?" : "") +
                    newSearchParamsString;
                window.history.replaceState({ path: url }, "", url);
            };
            clearUrlParams();
            if (this.autoResolvedFlow) {
                if (!this.resolved) {
                    this.resolved = true;
                    this.promise = Promise.resolve(this.autoResolvedFlow);
                    this.rejectPromise = this.resolvePromise = () => { };
                    log("Auto resolved");
                    this.emit("success");
                }
            }
            else {
                this.promise = new Promise((resolve, reject) => {
                    this.resolvePromise = (_) => {
                        const resolved = resolve(_);
                        this.resolved = true;
                        this.resolvedSuccessfully = true;
                        log("Xumm Sign in RESOLVED");
                        this.emit("success");
                        return resolved;
                    };
                    this.rejectPromise = (_) => {
                        const rejected = reject(_);
                        this.resolved = true;
                        this.emit("error", typeof _ === "string" ? new Error(_) : _);
                        log("Xumm Sign in REJECTED");
                        return rejected;
                    };
                });
            }
            return this.promise;
        });
    }
    state() {
        return __awaiter(this, void 0, void 0, function* () {
            return this.promise;
        });
    }
    logout() {
        var _a;
        // log("PKCE Logout");
        setTimeout(() => this.emit("loggedout"), 0);
        try {
            this.resolved = false;
            this.resolvedSuccessfully = undefined;
            this.autoResolvedFlow = undefined;
            (_a = this.options.storage) === null || _a === void 0 ? void 0 : _a.removeItem("XummPkceJwt");
            this.mobileRedirectFlow = false;
        }
        catch (e) {
            // Nothing to do
        }
        return;
    }
    getPopup() {
        return this === null || this === void 0 ? void 0 : this.popup;
    }
}
exports.XummPkceThread = XummPkceThread;
const thread = (_XummPkce) => {
    let attached = false;
    if (_XummPkce) {
        if (typeof window === "object") {
            if (typeof window._XummPkce === "undefined") {
                window._XummPkce = _XummPkce;
                attached = true;
            }
        }
    }
    const instance = window === null || window === void 0 ? void 0 : window._XummPkce;
    if (instance && attached) {
        log("XummPkce attached to window");
    }
    return instance;
};
class XummPkce {
    constructor(xummApiKey, optionsOrRedirectUrl) {
        if (typeof window === "undefined" || typeof document === "undefined") {
            return;
        }
        if (!thread()) {
            thread(new XummPkceThread(xummApiKey, optionsOrRedirectUrl));
        }
    }
    on(event, listener) {
        const t = thread();
        if (!t) {
            return;
        }
        t.on(event, listener);
        return this;
    }
    off(event, listener) {
        const t = thread();
        if (!t) {
            return;
        }
        t.off(event, listener);
        return this;
    }
    authorize() {
        const t = thread();
        if (!t) {
            return;
        }
        return t.authorize();
    }
    state() {
        const t = thread();
        if (!t) {
            return;
        }
        return t.state();
    }
    logout() {
        const t = thread();
        if (!t) {
            return;
        }
        return t.logout();
    }
}
exports.XummPkce = XummPkce;


/***/ })

}]);