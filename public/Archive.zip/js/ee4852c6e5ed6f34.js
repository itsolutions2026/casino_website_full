"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["vendor/xumm-js-pkce"],{

/***/ "./node_modules/xumm-js-pkce/dist/PKCE.js":
/*!************************************************!*\
  !*** ./node_modules/xumm-js-pkce/dist/PKCE.js ***!
  \************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
var sha256_1 = __importDefault(__webpack_require__(/*! crypto-js/sha256 */ "./node_modules/crypto-js/sha256.js"));
var enc_base64_1 = __importDefault(__webpack_require__(/*! crypto-js/enc-base64 */ "./node_modules/crypto-js/enc-base64.js"));
var lib_typedarrays_1 = __importDefault(__webpack_require__(/*! crypto-js/lib-typedarrays */ "./node_modules/crypto-js/lib-typedarrays.js"));
var PKCE = /** @class */ (function () {
    /**
     * Initialize the instance with configuration
     * @param {IConfig} config
     */
    function PKCE(config) {
        this.state = '';
        this.codeVerifier = '';
        this.config = config;
    }
    /**
     * Generate the authorize url
     * @param  {object} additionalParams include additional parameters in the query
     * @return Promise<string>
     */
    PKCE.prototype.authorizeUrl = function (additionalParams) {
        var _a, _b;
        if (additionalParams === void 0) { additionalParams = {}; }
        var queryString = new URLSearchParams(Object.assign(__assign({ response_type: ((_a = this.config) === null || _a === void 0 ? void 0 : _a.implicit) ? 'token' : 'code', client_id: this.config.client_id, state: this.getState(additionalParams.state || null), scope: this.config.requested_scopes, redirect_uri: this.config.redirect_uri }, (((_b = this.config) === null || _b === void 0 ? void 0 : _b.implicit)
            ? {}
            : {
                code_challenge: this.pkceChallengeFromVerifier(),
                code_challenge_method: 'S256',
            })), additionalParams)).toString();
        return "".concat(this.config.authorization_endpoint, "?").concat(queryString);
    };
    /**
     * Given the return url, get a token from the oauth server
     * @param  url current urlwith params from server
     * @param  {object} additionalParams include additional parameters in the request body
     * @return {Promise<ITokenResponse>}
     */
    PKCE.prototype.exchangeForAccessToken = function (url, additionalParams) {
        var _this = this;
        if (additionalParams === void 0) { additionalParams = {}; }
        return this.parseAuthResponseUrl(url).then(function (q) {
            var _a, _b;
            if ((_a = _this.config) === null || _a === void 0 ? void 0 : _a.implicit) {
                var tokenResponse_1 = {
                    access_token: '',
                    expires_in: 0,
                    refresh_expires_in: 0,
                    refresh_token: '',
                    scope: '',
                    token_type: '',
                };
                var urlParams = new URL(url).searchParams;
                urlParams.forEach(function (val, key) {
                    if (Object.keys(tokenResponse_1).indexOf(key) > -1) {
                        tokenResponse_1[key] = typeof tokenResponse_1[key] === 'number' ? Number(val) : String(val);
                    }
                });
                return Promise.resolve(Object.assign(tokenResponse_1, additionalParams));
            }
            // Regular PKCE, not implicit
            return fetch(_this.config.token_endpoint, {
                method: 'POST',
                body: new URLSearchParams(Object.assign(__assign({ grant_type: 'authorization_code', code: q.code, client_id: _this.config.client_id, redirect_uri: _this.config.redirect_uri }, (((_b = _this.config) === null || _b === void 0 ? void 0 : _b.implicit)
                    ? {}
                    : {
                        code_verifier: _this.getCodeVerifier(),
                    })), additionalParams)),
                headers: {
                    Accept: 'application/json',
                    'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
                },
            }).then(function (response) { return response.json(); });
        });
    };
    /**
     * Get the current codeVerifier or generate a new one
     * @return {string}
     */
    PKCE.prototype.getCodeVerifier = function () {
        if (this.codeVerifier === '') {
            this.codeVerifier = this.randomStringFromStorage('pkce_code_verifier');
        }
        return this.codeVerifier;
    };
    /**
     * Get the current state or generate a new one
     * @return {string}
     */
    PKCE.prototype.getState = function (explicit) {
        if (explicit === void 0) { explicit = null; }
        var stateKey = 'pkce_state';
        if (explicit !== null) {
            this.getStore().setItem(stateKey, explicit);
        }
        if (this.state === '') {
            this.state = this.randomStringFromStorage(stateKey);
        }
        return this.state;
    };
    /**
     * Get the query params as json from a auth response url
     * @param  {string} url a url expected to have AuthResponse params
     * @return {Promise<IAuthResponse>}
     */
    PKCE.prototype.parseAuthResponseUrl = function (url) {
        var params = new URL(url).searchParams;
        return this.validateAuthResponse({
            error: params.get('error'),
            query: params.get('query'),
            state: params.get('state'),
            code: params.get('code'),
        });
    };
    /**
     * Generate a code challenge
     * @return {Promise<string>}
     */
    PKCE.prototype.pkceChallengeFromVerifier = function () {
        var hashed = (0, sha256_1.default)(this.getCodeVerifier());
        return enc_base64_1.default.stringify(hashed).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    };
    /**
     * Get a random string from storage or store a new one and return it's value
     * @param  {string} key
     * @return {string}
     */
    PKCE.prototype.randomStringFromStorage = function (key) {
        var fromStorage = this.getStore().getItem(key);
        if (fromStorage === null) {
            this.getStore().setItem(key, lib_typedarrays_1.default.random(64));
        }
        return this.getStore().getItem(key) || '';
    };
    /**
     * Validates params from auth response
     * @param  {AuthResponse} queryParams
     * @return {Promise<IAuthResponse>}
     */
    PKCE.prototype.validateAuthResponse = function (queryParams) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            var _a;
            if (queryParams.error) {
                return reject({ error: queryParams.error });
            }
            if (queryParams.state !== _this.getState() && !((_a = _this.config) === null || _a === void 0 ? void 0 : _a.implicit)) {
                return reject({ error: 'Invalid State' });
            }
            return resolve(queryParams);
        });
    };
    /**
     * Get the storage (sessionStorage / localStorage) to use, defaults to sessionStorage
     * @return {Storage}
     */
    PKCE.prototype.getStore = function () {
        var _a;
        return ((_a = this.config) === null || _a === void 0 ? void 0 : _a.storage) || sessionStorage;
    };
    return PKCE;
}());
exports["default"] = PKCE;


/***/ })

}]);